import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import json
import os
from datetime import datetime

DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)

# =========================
# INITIALIZE SESSION STATE
# =========================
if "profile_completed" not in st.session_state:# to prevent to move to other pages if the user not log in
    st.session_state.profile_completed = False

if "profile" not in st.session_state: # initalize a new empty profile {} 
    st.session_state.profile = {}

if "patient_data" not in st.session_state:
    st.session_state.patient_data = pd.DataFrame(columns=[
        "Date", "Meal Time", "Timing", "Insulin Units",
        "Blood Sugar", "Ingredients", "Insulin Type",
        "FBS", "Activity"
    ])

if "login_msg" not in st.session_state:
    st.session_state.login_msg = ""

# =========================
# FILE HANDLING FUNCTIONS
# =========================
def save_patient_data():
    """
    Saves the current patient's profile/readings to json.
    Reads id from the session.state
    Called when a new file is created or new data is added to an existing profile
    """

    patient_id = st.session_state.profile["patient_id"]
    file_path = os.path.join(DATA_DIR, f"{patient_id}.json") 
    
    data = {
        "profile": st.session_state.profile,
        "patient_data": st.session_state.patient_data.to_dict(orient="records")
    }

    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4) 

def load_patient_data(patient_id, password):
    """
    Takes two arguments: "National ID" and "Password"
    Checks if the ID exists first
    If so, then it fetches the password from the ID json file and compares it with the given password
    If they match, Login successful
    Load a patient profile if National ID and password match."""
    file_path = os.path.join(DATA_DIR, f"{patient_id}.json") 
    if not os.path.exists(file_path):
        return False, "National ID not found"

    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if data["profile"]["password"] != password:
        return False, "Incorrect password"

    st.session_state.profile = data["profile"]
    st.session_state.patient_data = pd.DataFrame(data["patient_data"])
    st.session_state.profile_completed = True
    return True, "Logged in successfully"

def validate_profile_data(patient_id, password, name, age, phone, gmail, dtype):
    """
    Validate the inputs data
    
    Args:
        patient_id (number)
        password (string)
        name (string)
        age (age)
        phone (number)
        gmail (string)
        dtype (string)

    Returns:
        _boolean_: status of the validation
    """
    
    path = os.path.join("DATA_DIR", f"{patient_id}.json")

    if not patient_id.isdigit():
        st.error("National ID must contain digits only")
        return False

    if os.path.exists(path):
        st.error("Profile already exists")
        return False

    if not phone.isdigit():
        st.error("Phone must contain digits only")
        return False

    if "@" not in gmail or "." not in gmail:
        st.error("Invalid email format")
        return False

    return True

# =========================
# SIDEBAR NAVIGATION
# =========================
def show_logged_in_profile():
    """
    Display sidebar info and navigation
    Updates the profile ID in the navigation bar when the "submit" button clicked
    """
    st.sidebar.title("Diabetes Monitor")

    if st.session_state.profile_completed:
        st.sidebar.markdown(f"**Logged in as:** {st.session_state.profile['name']}")
    else:
        st.sidebar.markdown("**No profile logged in yet**")

    page = st.sidebar.radio(
        "Navigate",
        ["Profile", "Store Data", "Show Data", "Info Page"]
    )
    return page


page = show_logged_in_profile()

# =========================
# PROFILE PAGE
# =========================
if page == "Profile":
    st.header("👤 Patient Profile")

    # ==== LOGIN SECTION ====
    st.subheader("Already have a profile?")
    login_id = st.text_input("National ID")
    login_pwd = st.text_input("Password", type="password")

    if st.button("Login"):
        status, msg = load_patient_data(login_id, login_pwd)
        st.session_state.login_msg = msg
        
        if status:
            st.success(msg)
        else:
            st.error(msg)

    st.divider()

    # ==== CREATE PROFILE SECTION ====
    with st.expander("🆕 Create a new profile"):
        with st.form("create_profile_form"):
            patient_id = st.text_input("National ID")
            password = st.text_input("Password", type="password")
            name = st.text_input("Full Name")
            age = st.number_input("Age", 0, 120)
            phone = st.text_input("Phone Number")
            gmail = st.text_input("Gmail")
            dtype = st.selectbox("Diabetes Type", ["Type 1", "Type 2", "Gestational"])

            submit = st.form_submit_button("Create Profile")
            
            status = validate_profile_data(patient_id, password, name, age, phone, gmail, dtype)
            
            if status:
                st.session_state.profile = {
                    "patient_id": patient_id,
                    "password": password,
                    "name": name,
                    "age": age,
                    "phone": phone,
                    "gmail": gmail,
                    "type": dtype
                }

                st.session_state.patient_data = pd.DataFrame(columns=[
                    "Date", "Meal Time", "Timing", "Insulin Units",
                    "Blood Sugar", "Ingredients", "Insulin Type",
                    "FBS", "Activity"
                ])

                save_patient_data()
                st.session_state.profile_completed = True
                st.success("Profile created successfully")

# =========================
# STORE DATA PAGE
# =========================
elif page == "Store Data":
    if not st.session_state.profile_completed:
        st.warning("Please login or create a profile first.")
        st.stop()

    st.header("📝 Daily Log")

    with st.expander("➕ Add New Reading", expanded=True):
        with st.form("reading_form"):
            col1, col2 = st.columns(2)
            date = col1.date_input("Date")
            meal_time = col1.time_input("Meal Time")
            timing = col2.selectbox("Timing", ["Before Meal", "After Meal", "Night"])
            insulin_units = col2.number_input("Insulin Units", 0, 100)
            blood_sugar = col1.number_input("Blood Sugar (mg/dL)", 0, 600)
            insulin_type = col2.text_input("Insulin Type")
            ingredients = st.text_area("Meal Ingredients")
            fbs = st.checkbox("Fasting Blood Sugar")
            activity = st.checkbox("Did exercise?")

            submit = st.form_submit_button("Save Reading")
            if submit:
                new_row = {
                    "Date": str(date),
                    "Meal Time": str(meal_time),
                    "Timing": timing,
                    "Insulin Units": insulin_units,
                    "Blood Sugar": blood_sugar,
                    "Ingredients": ingredients,
                    "Insulin Type": insulin_type,
                    "FBS": fbs,
                    "Activity": activity
                }
                
                st.session_state.patient_data = pd.concat(
                    [st.session_state.patient_data, pd.DataFrame([new_row])],
                    ignore_index=True
                )
                
                save_patient_data()
                
                st.success("Reading saved successfully")
                
                if blood_sugar > 180:
                    st.warning("High blood sugar detected")
                    st.markdown("## go to the info page tab 3 section 01**")
                elif blood_sugar < 70:
                    st.error("Low blood sugar detected")
                    st.markdown("##go to the info page tab 3 section 02")
                else:
                    st.success('Keep going, YOU ARE PERFECT! ')

    st.subheader("📄 View & Edit Readings")

    if st.session_state.patient_data.empty:
        st.info("No readings recorded yet.")
    else:
        # Editable table
        edited_df = st.data_editor(
            st.session_state.patient_data,
            use_container_width=True,
            num_rows="dynamic",
        )

        if st.button("💾 Update Data"):
            st.session_state.patient_data = edited_df

            save_patient_data()

            st.success("Data updated successfully")

# =========================
# SHOW DATA PAGE
# =========================
elif page == "Show Data":
    if not st.session_state.profile_completed:
        st.warning("Please login or create a profile first.")
        st.stop()

    st.header("📊 Health Analytics")
    df = st.session_state.patient_data

    if df.empty:
        st.info("No data available")
    else:
        
        # ====== Average Blood Sugar Section ====== 
        avg_before = df[df["Timing"] == "Before Meal"]["Blood Sugar"].mean()
        avg_after = df[df["Timing"] == "After Meal"]["Blood Sugar"].mean()

        c1, c2 = st.columns(2)
        c1.metric("Avg Before Meal", f"{avg_before:.1f} mg/dL")
        c2.metric("Avg After Meal", f"{avg_after:.1f} mg/dL")


        # ======== Graphing Section ========

        # Split the data
        before_meal = df[df["Timing"] == "Before Meal"]
        after_meal = df[df["Timing"] == "After Meal"].reset_index(drop=True)
        

        # ---- Graph 1: Before Meal ----
        st.markdown("### Before Meal Blood Sugar")
        before_meal = df[df["Timing"] == "Before Meal"].reset_index(drop=True)

        fig1, ax1 = plt.subplots()
        ax1.plot(range(1, len(before_meal) + 1), before_meal["Blood Sugar"], marker="o")
        ax1.set_ylabel("Blood Sugar (mg/dL)")
        ax1.set_xlabel("Reading Number")
        ax1.grid(True)

        st.pyplot(fig1)


        # ---- Graph 2: After Meal ----
        st.markdown("### After Meal Blood Sugar")

        fig2, ax2 = plt.subplots()
        ax2.plot(range(1,len(after_meal)+1), after_meal["Blood Sugar"], marker="o")
        ax2.set_ylabel("Blood Sugar (mg/dL)")
        ax2.set_xlabel("Reading Number")
        ax2.grid(True)

        st.pyplot(fig2)



        low_days = df[(df["Blood Sugar"] < 75) & (df["Timing"] == "After Meal")]
        high_days = df[(df["Blood Sugar"] > 150) & (df["Timing"] == "Before Meal")]


        if high_days.empty and low_days.empty:
             st.success("No abnormal readings")
        else:
            if not low_days.empty:
                st.subheader("⚠️ Abnormal Days: LOW Records")
                st.table(low_days.style.highlight_max(axis=0, color='#FEB05D'))
                
            if not high_days.empty:
                st.subheader("⚠️ Abnormal Days: HIGH Records")
                st.table(high_days.style.highlight_max(axis=0, color='#D73535'))
            
# =========================
# INFO PAGE
# =========================
elif page == "Info Page":
    st.header("ℹ️ Education Center")
    tab1, tab2, tab3 = st.tabs(["General & Emergency", "Nutrition", "What Should I Do?"])

    with tab1:
        st.markdown("### General Instructions")
        st.write("- Monitor sugar daily\n- Stay hydrated\n- Carry fast sugar")
        st.write('measure your sugar level daily and if you feel you are in not good state feel free to call your doctor')
        

    with tab2:
        col1, col2 = st.columns(2)
        col1.success("Healthy foods: vegetables, lean protein")
        col2.warning("Avoid: sugar drinks, white bread")

    with tab3:
        with st.expander("High Blood Sugar \nsection 01"):
            st.write("Drink water, walk lightly, check insulin")
            
        with st.expander("Low Blood Sugar\nsectoin 02"):
            st.write("Eat fast sugar, rest, re-check level")
